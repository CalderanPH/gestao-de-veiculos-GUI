# SISTEM DE GESTÃO DE VEÍCULOS
 É um trabalho que venho desenvolvendo para pós graduação semanalmente, aplicando todos os recursos de JAVA.
 
 O trabalho compõe várias classes, sendo um como simulação de Banco de dados, apenas para teste que na qual os dados do ArrayList e os metodos cadastrar veículo, consultar e excluir ficam na mesma classe sendo BDVeiculos.
 O sistema tem a finalidade de registrar um veículo de passeio e outro de carga, estas classes herdam os atributos em comum na classe veículo, os parametros não são definidos 
 pelo programador mas sim pelo usuário via entrada de dados pelo console. 
 Próxima atualização vai conter a interface GUI, ficando mais fácil a interação do usuário ao sistema.
